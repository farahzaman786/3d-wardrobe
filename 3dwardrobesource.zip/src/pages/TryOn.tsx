import { useWardrobe } from '../state/WardrobeContext'
import { useAvatar } from '../state/AvatarContext'
import { AvatarScene } from '../components/AvatarScene'
import type { GarmentCategory } from '../lib/types'

const CATEGORIES: { value: GarmentCategory; label: string }[] = [
  { value: 'shirts', label: 'Shirts' },
  { value: 'jackets', label: 'Jackets' },
  { value: 'trousers', label: 'Trousers' },
  { value: 'shoes', label: 'Shoes' },
  { value: 'accessories', label: 'Accessories' },
]

export function TryOn() {
  const { items, outfit, setOutfitItem } = useWardrobe()
  const { measurements } = useAvatar()

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-white mb-2">Virtual Try-On</h1>
      <p className="text-slate-400 mb-6 max-w-2xl">
        Pick one item per category to build an outfit on your avatar.
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="h-96 rounded-lg overflow-hidden bg-slate-900 border border-slate-800">
          <AvatarScene measurements={measurements} outfit={outfit} items={items} className="w-full h-full" />
        </div>

        <div className="space-y-5">
          {CATEGORIES.map((cat) => {
            const catItems = items.filter((i) => i.category === cat.value)
            const selectedId = outfit[cat.value]
            return (
              <div key={cat.value}>
                <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wide mb-2">
                  {cat.label}
                </h2>
                {catItems.length === 0 ? (
                  <p className="text-slate-600 text-sm">No {cat.label.toLowerCase()} in your wardrobe yet.</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => setOutfitItem(cat.value, undefined)}
                      className={`px-3 py-1.5 rounded-md text-xs font-medium border ${
                        !selectedId
                          ? 'bg-slate-700 border-slate-600 text-white'
                          : 'border-slate-800 text-slate-400 hover:border-slate-600'
                      }`}
                    >
                      None
                    </button>
                    {catItems.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setOutfitItem(cat.value, item.id)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium border ${
                          selectedId === item.id
                            ? 'bg-indigo-600 border-indigo-500 text-white'
                            : 'border-slate-800 text-slate-300 hover:border-slate-600'
                        }`}
                      >
                        <span
                          className="h-3 w-3 rounded-full border border-white/30"
                          style={{ backgroundColor: item.color }}
                        />
                        {item.name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
