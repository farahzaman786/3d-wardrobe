import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import type { PoseLandmarker } from '@mediapipe/tasks-vision'
import { useAvatar } from '../state/AvatarContext'
import { AvatarScene } from '../components/AvatarScene'
import { loadPoseLandmarker } from '../lib/poseLandmarker'
import { estimateMeasurementsFromLandmarks } from '../lib/measurements'
import type { BodyMeasurements } from '../lib/types'

const SLIDER_CONFIG: { key: keyof BodyMeasurements; label: string; min: number; max: number }[] = [
  { key: 'heightCm', label: 'Height (cm)', min: 140, max: 210 },
  { key: 'shoulderWidthCm', label: 'Shoulder width (cm)', min: 30, max: 55 },
  { key: 'waistWidthCm', label: 'Waist width (cm)', min: 22, max: 50 },
  { key: 'legLengthCm', label: 'Leg length (cm)', min: 60, max: 100 },
  { key: 'armLengthCm', label: 'Arm length (cm)', min: 45, max: 75 },
]

type ScanStatus = 'idle' | 'starting' | 'live' | 'error'

export function BodyScan() {
  const { measurements, setMeasurements } = useAvatar()
  const navigate = useNavigate()

  const [draft, setDraft] = useState<BodyMeasurements>(measurements)
  const [reportedHeight, setReportedHeight] = useState(measurements.heightCm)
  const [status, setStatus] = useState<ScanStatus>('idle')
  const [error, setError] = useState<string | null>(null)
  const [captured, setCaptured] = useState(false)

  const videoRef = useRef<HTMLVideoElement | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const landmarkerRef = useRef<PoseLandmarker | null>(null)
  const rafRef = useRef<number | null>(null)
  const latestLandmarksRef = useRef<{ x: number; y: number; z: number }[] | null>(null)

  useEffect(() => {
    return () => stopCamera()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function startCamera() {
    setError(null)
    setStatus('starting')
    try {
      const [stream, landmarker] = await Promise.all([
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } }),
        loadPoseLandmarker(),
      ])
      streamRef.current = stream
      landmarkerRef.current = landmarker
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }
      setStatus('live')
      loop()
    } catch (err) {
      console.error(err)
      setError(
        err instanceof Error
          ? err.message
          : 'Could not access the camera. Check permissions and try again.',
      )
      setStatus('error')
    }
  }

  function stopCamera() {
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
    streamRef.current?.getTracks().forEach((t) => t.stop())
    streamRef.current = null
    setStatus('idle')
  }

  function loop() {
    const video = videoRef.current
    const landmarker = landmarkerRef.current
    if (!video || !landmarker) return
    if (video.readyState >= 2) {
      const result = landmarker.detectForVideo(video, performance.now())
      if (result.worldLandmarks?.[0]) {
        latestLandmarksRef.current = result.worldLandmarks[0]
      }
    }
    rafRef.current = requestAnimationFrame(loop)
  }

  function capture() {
    const landmarks = latestLandmarksRef.current
    if (!landmarks) {
      setError('No pose detected yet — step back so your full body is visible.')
      return
    }
    const next = estimateMeasurementsFromLandmarks(landmarks, reportedHeight)
    setDraft(next)
    setCaptured(true)
    setError(null)
  }

  function saveAndContinue() {
    setMeasurements(draft)
    navigate('/wardrobe')
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-white mb-2">Body Scan</h1>
      <p className="text-slate-400 mb-6 max-w-2xl">
        Stand back so your full body is in frame, enter your real height for
        calibration, then capture a pose. This estimates proportions from a
        regular camera — it's an approximation, not a lab-grade scan. You can
        always fine-tune with the sliders, or skip straight to manual entry.
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <label className="block text-sm text-slate-300 mb-1">Your height (cm)</label>
          <input
            type="number"
            value={reportedHeight}
            onChange={(e) => setReportedHeight(Number(e.target.value))}
            className="w-32 rounded-md bg-slate-900 border border-slate-700 px-3 py-2 text-white mb-4"
          />

          <div className="relative bg-slate-900 rounded-lg overflow-hidden aspect-video border border-slate-800">
            <video
              ref={videoRef}
              muted
              playsInline
              className="w-full h-full object-cover -scale-x-100"
            />
            {status === 'idle' && (
              <div className="absolute inset-0 flex items-center justify-center text-slate-500 text-sm">
                Camera off
              </div>
            )}
          </div>

          <div className="flex gap-2 mt-3">
            {status !== 'live' ? (
              <button
                onClick={startCamera}
                disabled={status === 'starting'}
                className="px-4 py-2 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium disabled:opacity-50"
              >
                {status === 'starting' ? 'Starting camera…' : 'Start camera'}
              </button>
            ) : (
              <>
                <button
                  onClick={capture}
                  className="px-4 py-2 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium"
                >
                  Capture pose
                </button>
                <button
                  onClick={stopCamera}
                  className="px-4 py-2 rounded-md bg-slate-800 hover:bg-slate-700 text-white text-sm font-medium"
                >
                  Stop camera
                </button>
              </>
            )}
          </div>
          {error && <p className="text-rose-400 text-sm mt-2">{error}</p>}
          {captured && !error && (
            <p className="text-emerald-400 text-sm mt-2">
              Captured — adjust with the sliders if anything looks off, then save.
            </p>
          )}
        </div>

        <div>
          <div className="h-64 md:h-72 rounded-lg overflow-hidden bg-slate-900 border border-slate-800 mb-4">
            <AvatarScene measurements={draft} className="w-full h-full" />
          </div>

          <div className="space-y-3">
            {SLIDER_CONFIG.map((cfg) => (
              <div key={cfg.key}>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>{cfg.label}</span>
                  <span>{draft[cfg.key]}</span>
                </div>
                <input
                  type="range"
                  min={cfg.min}
                  max={cfg.max}
                  step={0.5}
                  value={draft[cfg.key]}
                  onChange={(e) =>
                    setDraft((prev) => ({ ...prev, [cfg.key]: Number(e.target.value) }))
                  }
                  className="w-full accent-indigo-500"
                />
              </div>
            ))}
          </div>

          <button
            onClick={saveAndContinue}
            className="mt-5 w-full rounded-md bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-2 transition-colors"
          >
            Save avatar &amp; continue
          </button>
        </div>
      </div>
    </div>
  )
}
