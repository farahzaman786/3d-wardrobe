import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../state/AuthContext'

export function SignUp() {
  const [email, setEmail] = useState('')
  const { signUp } = useAuth()
  const navigate = useNavigate()

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!email.trim()) return
    signUp(email.trim())
    navigate('/scan')
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <h1 className="text-3xl font-bold text-white mb-1">3D Wardrobe</h1>
        <p className="text-slate-400 mb-8">
          See exactly how your clothes will look on you, before you wear them.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-slate-300 mb-1">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-md bg-slate-900 border border-slate-700 px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <button
            type="submit"
            className="w-full rounded-md bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-2 transition-colors"
          >
            Continue
          </button>
        </form>

        <p className="mt-6 text-xs text-slate-500 leading-relaxed">
          Prototype note: this is a local, email-only sign-in for demoing the product
          flow — no password, no server. Swap for real Firebase/Auth before shipping.
        </p>
      </div>
    </div>
  )
}
