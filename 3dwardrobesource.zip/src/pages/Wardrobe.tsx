import { useState, type FormEvent } from 'react'
import { useWardrobe } from '../state/WardrobeContext'
import type { GarmentCategory } from '../lib/types'

const CATEGORIES: { value: GarmentCategory; label: string }[] = [
  { value: 'shirts', label: 'Shirts' },
  { value: 'trousers', label: 'Trousers' },
  { value: 'jackets', label: 'Jackets' },
  { value: 'shoes', label: 'Shoes' },
  { value: 'accessories', label: 'Accessories' },
]

export function Wardrobe() {
  const { items, addItem, removeItem } = useWardrobe()
  const [name, setName] = useState('')
  const [category, setCategory] = useState<GarmentCategory>('shirts')
  const [color, setColor] = useState('#4f7cff')

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!name.trim()) return
    addItem(name.trim(), category, color)
    setName('')
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-white mb-2">Digital Wardrobe</h1>
      <p className="text-slate-400 mb-6 max-w-2xl">
        Add the clothes you own. For this prototype each item is a named,
        categorized, colored placeholder garment — swap in real 3D garment
        assets per category later without changing this data model.
      </p>

      <form onSubmit={handleSubmit} className="flex flex-wrap items-end gap-3 mb-8 bg-slate-900 border border-slate-800 rounded-lg p-4">
        <div>
          <label className="block text-xs text-slate-400 mb-1">Name</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Blue oxford shirt"
            className="rounded-md bg-slate-950 border border-slate-700 px-3 py-2 text-white text-sm w-56"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Category</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as GarmentCategory)}
            className="rounded-md bg-slate-950 border border-slate-700 px-3 py-2 text-white text-sm"
          >
            {CATEGORIES.map((c) => (
              <option key={c.value} value={c.value}>
                {c.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Color</label>
          <input
            type="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            className="h-10 w-14 rounded-md bg-slate-950 border border-slate-700"
          />
        </div>
        <button
          type="submit"
          className="px-4 py-2 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium"
        >
          Add item
        </button>
      </form>

      {CATEGORIES.map((cat) => {
        const catItems = items.filter((i) => i.category === cat.value)
        if (catItems.length === 0) return null
        return (
          <div key={cat.value} className="mb-6">
            <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wide mb-2">
              {cat.label}
            </h2>
            <div className="flex flex-wrap gap-3">
              {catItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center gap-3 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2"
                >
                  <span
                    className="h-6 w-6 rounded-full border border-slate-700"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-white text-sm">{item.name}</span>
                  <button
                    onClick={() => removeItem(item.id)}
                    className="text-slate-500 hover:text-rose-400 text-xs"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>
        )
      })}

      {items.length === 0 && (
        <p className="text-slate-500 text-sm">Your wardrobe is empty — add your first item above.</p>
      )}
    </div>
  )
}
