import { createContext, useContext, useState, type ReactNode } from 'react'
import { loadJSON, saveJSON } from '../lib/storage'
import type { User } from '../lib/types'

interface AuthContextValue {
  user: User | null
  signUp: (email: string) => void
  signOut: () => void
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => loadJSON('user', null))

  function signUp(email: string) {
    const nextUser = { email }
    setUser(nextUser)
    saveJSON('user', nextUser)
  }

  function signOut() {
    setUser(null)
    saveJSON('user', null)
  }

  return (
    <AuthContext.Provider value={{ user, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
