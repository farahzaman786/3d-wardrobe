import { createContext, useContext, useState, type ReactNode } from 'react'
import { loadJSON, saveJSON } from '../lib/storage'
import type { GarmentItem, GarmentCategory, Outfit } from '../lib/types'

interface WardrobeContextValue {
  items: GarmentItem[]
  addItem: (name: string, category: GarmentCategory, color: string) => void
  removeItem: (id: string) => void
  outfit: Outfit
  setOutfitItem: (category: GarmentCategory, itemId: string | undefined) => void
}

const WardrobeContext = createContext<WardrobeContextValue | null>(null)

export function WardrobeProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<GarmentItem[]>(() => loadJSON('garments', []))
  const [outfit, setOutfit] = useState<Outfit>(() => loadJSON('outfit', {}))

  function addItem(name: string, category: GarmentCategory, color: string) {
    const item: GarmentItem = {
      id: crypto.randomUUID(),
      name,
      category,
      color,
      createdAt: Date.now(),
    }
    const next = [...items, item]
    setItems(next)
    saveJSON('garments', next)
  }

  function removeItem(id: string) {
    const next = items.filter((i) => i.id !== id)
    setItems(next)
    saveJSON('garments', next)
    const nextOutfit = { ...outfit }
    for (const cat of Object.keys(nextOutfit) as GarmentCategory[]) {
      if (nextOutfit[cat] === id) delete nextOutfit[cat]
    }
    setOutfit(nextOutfit)
    saveJSON('outfit', nextOutfit)
  }

  function setOutfitItem(category: GarmentCategory, itemId: string | undefined) {
    const next = { ...outfit, [category]: itemId }
    if (!itemId) delete next[category]
    setOutfit(next)
    saveJSON('outfit', next)
  }

  return (
    <WardrobeContext.Provider value={{ items, addItem, removeItem, outfit, setOutfitItem }}>
      {children}
    </WardrobeContext.Provider>
  )
}

export function useWardrobe() {
  const ctx = useContext(WardrobeContext)
  if (!ctx) throw new Error('useWardrobe must be used within WardrobeProvider')
  return ctx
}
