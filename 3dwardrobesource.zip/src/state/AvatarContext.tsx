import { createContext, useContext, useState, type ReactNode } from 'react'
import { loadJSON, saveJSON, DEFAULT_MEASUREMENTS } from '../lib/storage'
import type { BodyMeasurements } from '../lib/types'

interface AvatarContextValue {
  measurements: BodyMeasurements
  setMeasurements: (m: BodyMeasurements) => void
  lastScanAt: number | null
}

const AvatarContext = createContext<AvatarContextValue | null>(null)

export function AvatarProvider({ children }: { children: ReactNode }) {
  const [measurements, setMeasurementsState] = useState<BodyMeasurements>(() =>
    loadJSON('measurements', DEFAULT_MEASUREMENTS),
  )
  const [lastScanAt, setLastScanAt] = useState<number | null>(() =>
    loadJSON('lastScanAt', null),
  )

  function setMeasurements(m: BodyMeasurements) {
    setMeasurementsState(m)
    saveJSON('measurements', m)
    const now = Date.now()
    setLastScanAt(now)
    saveJSON('lastScanAt', now)
  }

  return (
    <AvatarContext.Provider value={{ measurements, setMeasurements, lastScanAt }}>
      {children}
    </AvatarContext.Provider>
  )
}

export function useAvatar() {
  const ctx = useContext(AvatarContext)
  if (!ctx) throw new Error('useAvatar must be used within AvatarProvider')
  return ctx
}
