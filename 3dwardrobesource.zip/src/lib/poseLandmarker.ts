import { FilesetResolver, PoseLandmarker } from '@mediapipe/tasks-vision'

let cached: Promise<PoseLandmarker> | null = null

/**
 * Lazily loads MediaPipe's PoseLandmarker (WASM + model, fetched from Google's
 * CDN on first use, then cached by the browser). Runs entirely client-side —
 * no video frames ever leave the device.
 */
export function loadPoseLandmarker(): Promise<PoseLandmarker> {
  if (!cached) {
    cached = (async () => {
      const vision = await FilesetResolver.forVisionTasks(
        'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm',
      )
      return PoseLandmarker.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath:
            'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task',
          delegate: 'GPU',
        },
        runningMode: 'VIDEO',
        numPoses: 1,
      })
    })()
  }
  return cached
}
