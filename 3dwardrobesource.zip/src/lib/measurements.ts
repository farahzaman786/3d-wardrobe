import type { BodyMeasurements } from './types'

// BlazePose (MediaPipe Pose Landmarker) 33-point landmark indices we care about.
export const POSE_LANDMARKS = {
  nose: 0,
  leftShoulder: 11,
  rightShoulder: 12,
  leftElbow: 13,
  rightElbow: 14,
  leftWrist: 15,
  rightWrist: 16,
  leftHip: 23,
  rightHip: 24,
  leftKnee: 25,
  rightKnee: 26,
  leftAnkle: 27,
  rightAnkle: 28,
} as const

export interface Landmark3D {
  x: number
  y: number
  z: number
}

function dist(a: Landmark3D, b: Landmark3D): number {
  return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2)
}

function midpoint(a: Landmark3D, b: Landmark3D): Landmark3D {
  return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: (a.z + b.z) / 2 }
}

/**
 * Derives approximate body measurements from a single-frame pose landmark set.
 * MediaPipe's "world landmarks" are metric but not reliably calibrated to true
 * scale from a single RGB frame, so we calibrate using the user's self-reported
 * height (the same approach real single-camera measurement apps use).
 */
export function estimateMeasurementsFromLandmarks(
  landmarks: Landmark3D[],
  reportedHeightCm: number,
): BodyMeasurements {
  const L = POSE_LANDMARKS
  const leftShoulder = landmarks[L.leftShoulder]
  const rightShoulder = landmarks[L.rightShoulder]
  const leftElbow = landmarks[L.leftElbow]
  const rightElbow = landmarks[L.rightElbow]
  const leftWrist = landmarks[L.leftWrist]
  const rightWrist = landmarks[L.rightWrist]
  const leftHip = landmarks[L.leftHip]
  const rightHip = landmarks[L.rightHip]
  const leftKnee = landmarks[L.leftKnee]
  const rightKnee = landmarks[L.rightKnee]
  const leftAnkle = landmarks[L.leftAnkle]
  const rightAnkle = landmarks[L.rightAnkle]
  const nose = landmarks[L.nose]

  const ankleMid = midpoint(leftAnkle, rightAnkle)
  // Rough head-to-heel proxy: nose-to-ankle distance, scaled up slightly to
  // account for the top of the head above the nose and the foot below the ankle.
  const noseToAnkleRaw = dist(nose, ankleMid) * 1.15

  const shoulderWidthRaw = dist(leftShoulder, rightShoulder)
  const waistWidthRaw = dist(leftHip, rightHip) * 1.05
  const legLengthRaw =
    (dist(leftHip, leftKnee) +
      dist(leftKnee, leftAnkle) +
      dist(rightHip, rightKnee) +
      dist(rightKnee, rightAnkle)) /
    2
  const armLengthRaw =
    (dist(leftShoulder, leftElbow) +
      dist(leftElbow, leftWrist) +
      dist(rightShoulder, rightElbow) +
      dist(rightElbow, rightWrist)) /
    2

  // Calibrate: landmark units -> cm, using reported height as ground truth.
  const scale = noseToAnkleRaw > 0 ? reportedHeightCm / (noseToAnkleRaw * 100) : 1

  return {
    heightCm: reportedHeightCm,
    shoulderWidthCm: round1(shoulderWidthRaw * 100 * scale),
    waistWidthCm: round1(waistWidthRaw * 100 * scale),
    legLengthCm: round1(legLengthRaw * 100 * scale),
    armLengthCm: round1(armLengthRaw * 100 * scale),
  }
}

function round1(n: number): number {
  return Math.round(n * 10) / 10
}
