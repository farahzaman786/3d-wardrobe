export type GarmentCategory =
  | 'shirts'
  | 'trousers'
  | 'jackets'
  | 'shoes'
  | 'accessories'

export interface BodyMeasurements {
  heightCm: number
  shoulderWidthCm: number
  waistWidthCm: number
  legLengthCm: number
  armLengthCm: number
}

export interface GarmentItem {
  id: string
  name: string
  category: GarmentCategory
  color: string
  createdAt: number
}

export type Outfit = Partial<Record<GarmentCategory, string>>

export interface User {
  email: string
}
