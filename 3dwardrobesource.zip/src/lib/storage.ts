const PREFIX = '3d-wardrobe:'

export function loadJSON<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key)
    if (!raw) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

export function saveJSON<T>(key: string, value: T): void {
  localStorage.setItem(PREFIX + key, JSON.stringify(value))
}

export const DEFAULT_MEASUREMENTS = {
  heightCm: 170,
  shoulderWidthCm: 40,
  waistWidthCm: 32,
  legLengthCm: 80,
  armLengthCm: 60,
}
