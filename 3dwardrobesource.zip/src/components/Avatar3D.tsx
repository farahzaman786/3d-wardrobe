import { useMemo } from 'react'
import type { BodyMeasurements, GarmentCategory, Outfit } from '../lib/types'
import type { GarmentItem } from '../lib/types'

interface Avatar3DProps {
  measurements: BodyMeasurements
  outfit?: Outfit
  items?: GarmentItem[]
}

const BASE_HEIGHT_CM = 170

/** Scales all body proportions relative to a 170cm baseline rig. */
function useAvatarScale(measurements: BodyMeasurements) {
  return useMemo(() => {
    const s = measurements.heightCm / BASE_HEIGHT_CM
    return {
      overall: s,
      shoulderWidth: measurements.shoulderWidthCm / 40,
      waistWidth: measurements.waistWidthCm / 32,
      legLength: measurements.legLengthCm / 80,
      armLength: measurements.armLengthCm / 60,
    }
  }, [measurements])
}

function garmentColor(items: GarmentItem[] | undefined, outfit: Outfit | undefined, category: GarmentCategory, fallback: string) {
  const id = outfit?.[category]
  const item = items?.find((i) => i.id === id)
  return item?.color ?? fallback
}

const SKIN = '#e0ac8b'

export function Avatar3D({ measurements, outfit, items }: Avatar3DProps) {
  const scale = useAvatarScale(measurements)

  const torsoH = 0.6 * scale.overall
  const legH = 0.8 * scale.legLength
  const armLen = 0.55 * scale.armLength
  const shoulderW = 0.5 * scale.shoulderWidth
  const waistW = 0.34 * scale.waistWidth

  const hasShirt = Boolean(outfit?.shirts)
  const hasJacket = Boolean(outfit?.jackets)
  const hasTrousers = Boolean(outfit?.trousers)
  const hasShoes = Boolean(outfit?.shoes)
  const hasAccessory = Boolean(outfit?.accessories)

  const shirtColor = garmentColor(items, outfit, 'shirts', '#4f7cff')
  const jacketColor = garmentColor(items, outfit, 'jackets', '#2b2b3d')
  const trouserColor = garmentColor(items, outfit, 'trousers', '#2f3542')
  const shoeColor = garmentColor(items, outfit, 'shoes', '#1a1a1a')
  const accessoryColor = garmentColor(items, outfit, 'accessories', '#d4af37')

  const legGap = waistW * 0.28
  const legTopY = legH / 2
  const hipY = legH
  const torsoTopY = hipY + torsoH
  const headR = 0.14 * scale.overall

  return (
    <group position={[0, -legH - torsoH / 2, 0]}>
      {/* Legs */}
      <mesh position={[-legGap, legTopY, 0]} castShadow>
        <capsuleGeometry args={[waistW * 0.22, legH * 0.8, 4, 8]} />
        <meshStandardMaterial color={hasTrousers ? trouserColor : SKIN} />
      </mesh>
      <mesh position={[legGap, legTopY, 0]} castShadow>
        <capsuleGeometry args={[waistW * 0.22, legH * 0.8, 4, 8]} />
        <meshStandardMaterial color={hasTrousers ? trouserColor : SKIN} />
      </mesh>

      {/* Shoes */}
      <mesh position={[-legGap, 0.05, 0.05]} castShadow>
        <boxGeometry args={[waistW * 0.28, 0.1, 0.28]} />
        <meshStandardMaterial color={hasShoes ? shoeColor : '#8a8a8a'} />
      </mesh>
      <mesh position={[legGap, 0.05, 0.05]} castShadow>
        <boxGeometry args={[waistW * 0.28, 0.1, 0.28]} />
        <meshStandardMaterial color={hasShoes ? shoeColor : '#8a8a8a'} />
      </mesh>

      {/* Torso */}
      <mesh position={[0, hipY + torsoH / 2, 0]} castShadow>
        <capsuleGeometry args={[waistW * 0.55, torsoH * 0.6, 4, 8]} />
        <meshStandardMaterial color={hasShirt || hasJacket ? (hasJacket ? jacketColor : shirtColor) : SKIN} />
      </mesh>

      {/* Jacket overlay (slightly larger torso shell) when both shirt+jacket equipped */}
      {hasJacket && (
        <mesh position={[0, hipY + torsoH / 2, 0]} castShadow>
          <capsuleGeometry args={[waistW * 0.62, torsoH * 0.62, 4, 8]} />
          <meshStandardMaterial color={jacketColor} transparent opacity={0.95} />
        </mesh>
      )}

      {/* Arms */}
      <mesh
        position={[-shoulderW / 2 - 0.06, torsoTopY - armLen / 2, 0]}
        rotation={[0, 0, 0.06]}
        castShadow
      >
        <capsuleGeometry args={[0.07 * scale.overall, armLen * 0.85, 4, 8]} />
        <meshStandardMaterial color={hasJacket ? jacketColor : hasShirt ? shirtColor : SKIN} />
      </mesh>
      <mesh
        position={[shoulderW / 2 + 0.06, torsoTopY - armLen / 2, 0]}
        rotation={[0, 0, -0.06]}
        castShadow
      >
        <capsuleGeometry args={[0.07 * scale.overall, armLen * 0.85, 4, 8]} />
        <meshStandardMaterial color={hasJacket ? jacketColor : hasShirt ? shirtColor : SKIN} />
      </mesh>

      {/* Head */}
      <mesh position={[0, torsoTopY + headR + 0.03, 0]} castShadow>
        <sphereGeometry args={[headR, 24, 24]} />
        <meshStandardMaterial color={SKIN} />
      </mesh>

      {/* Accessory: simple necklace/band indicator */}
      {hasAccessory && (
        <mesh position={[0, torsoTopY + 0.02, waistW * 0.5]}>
          <torusGeometry args={[0.09 * scale.overall, 0.015 * scale.overall, 8, 16]} />
          <meshStandardMaterial color={accessoryColor} metalness={0.6} roughness={0.3} />
        </mesh>
      )}
    </group>
  )
}
