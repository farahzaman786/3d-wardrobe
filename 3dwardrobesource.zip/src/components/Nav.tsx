import { NavLink } from 'react-router-dom'
import { useAuth } from '../state/AuthContext'

const linkClass = ({ isActive }: { isActive: boolean }) =>
  `px-3 py-2 rounded-md text-sm font-medium transition-colors ${
    isActive ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'
  }`

export function Nav() {
  const { user, signOut } = useAuth()

  return (
    <nav className="flex items-center justify-between px-6 py-3 bg-slate-950 border-b border-slate-800">
      <div className="flex items-center gap-2">
        <span className="text-lg font-semibold text-white">3D Wardrobe</span>
      </div>
      {user && (
        <div className="flex items-center gap-1">
          <NavLink to="/scan" className={linkClass}>
            Body Scan
          </NavLink>
          <NavLink to="/wardrobe" className={linkClass}>
            Wardrobe
          </NavLink>
          <NavLink to="/try-on" className={linkClass}>
            Try-On
          </NavLink>
          <span className="mx-2 text-slate-600">|</span>
          <span className="text-sm text-slate-400">{user.email}</span>
          <button
            onClick={signOut}
            className="ml-2 px-3 py-2 rounded-md text-sm text-slate-300 hover:text-white hover:bg-slate-800"
          >
            Sign out
          </button>
        </div>
      )}
    </nav>
  )
}
