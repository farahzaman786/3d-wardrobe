import { Canvas } from '@react-three/fiber'
import { OrbitControls, ContactShadows } from '@react-three/drei'
import { Avatar3D } from './Avatar3D'
import { CanvasErrorBoundary } from './CanvasErrorBoundary'
import type { BodyMeasurements, GarmentItem, Outfit } from '../lib/types'

interface AvatarSceneProps {
  measurements: BodyMeasurements
  outfit?: Outfit
  items?: GarmentItem[]
  className?: string
}

export function AvatarScene({ measurements, outfit, items, className }: AvatarSceneProps) {
  return (
    <div className={className}>
      <CanvasErrorBoundary>
        <Canvas shadows camera={{ position: [0, 0.2, 2.4], fov: 40 }}>
          <ambientLight intensity={0.7} />
          <directionalLight position={[2, 3, 2]} intensity={1.4} castShadow />
          <directionalLight position={[-2, 1, -1]} intensity={0.4} />
          <Avatar3D measurements={measurements} outfit={outfit} items={items} />
          <ContactShadows position={[0, -1.02, 0]} opacity={0.4} scale={3} blur={2} />
          <OrbitControls
            enablePan={false}
            minDistance={1.4}
            maxDistance={4}
            target={[0, 0, 0]}
          />
        </Canvas>
      </CanvasErrorBoundary>
    </div>
  )
}
