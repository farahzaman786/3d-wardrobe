import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import type { ReactNode } from 'react'
import { AuthProvider, useAuth } from './state/AuthContext'
import { AvatarProvider } from './state/AvatarContext'
import { WardrobeProvider } from './state/WardrobeContext'
import { Nav } from './components/Nav'
import { SignUp } from './pages/SignUp'
import { BodyScan } from './pages/BodyScan'
import { Wardrobe } from './pages/Wardrobe'
import { TryOn } from './pages/TryOn'

function RequireAuth({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/" replace />
  return <>{children}</>
}

function AppRoutes() {
  const { user } = useAuth()

  return (
    <Routes>
      <Route path="/" element={user ? <Navigate to="/scan" replace /> : <SignUp />} />
      <Route
        path="/scan"
        element={
          <RequireAuth>
            <BodyScan />
          </RequireAuth>
        }
      />
      <Route
        path="/wardrobe"
        element={
          <RequireAuth>
            <Wardrobe />
          </RequireAuth>
        }
      />
      <Route
        path="/try-on"
        element={
          <RequireAuth>
            <TryOn />
          </RequireAuth>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AvatarProvider>
          <WardrobeProvider>
            <div className="min-h-screen bg-slate-950">
              <Nav />
              <AppRoutes />
            </div>
          </WardrobeProvider>
        </AvatarProvider>
      </AuthProvider>
    </BrowserRouter>
  )
}

export default App
