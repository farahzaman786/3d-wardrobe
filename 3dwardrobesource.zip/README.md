# 3D Wardrobe

A browser-based prototype of the 3D Wardrobe product concept: sign up, scan your
body via webcam, build a digital wardrobe, and try on outfits on a 3D avatar.

This is an MVP built for fast iteration in the browser — no native mobile app,
no server, no cloud storage yet. Everything is scoped to be honestly buildable
by one person, not a research-grade body scanner or cloth simulator. See
"Scope and honest limitations" below.

## Stack

- Vite + React + TypeScript
- Tailwind CSS
- react-three-fiber + drei (Three.js) for the 3D avatar/scene
- MediaPipe Tasks Vision (Pose Landmarker) for webcam-based body pose estimation
- `localStorage` for all persistence (no backend yet)

## Getting started

```bash
npm install
npm run dev
```

Open the printed local URL. Sign up with any email (no password — it's a local
demo stub, not real auth), then:

1. **Body Scan** — enter your real height (used to calibrate camera-based
   measurements), click "Start camera," stand back so your full body is in
   frame, and click "Capture pose." Or skip straight to the sliders on the
   right to enter measurements manually.
2. **Wardrobe** — add clothing items with a name, category, and color.
3. **Try-On** — pick one item per category and see it composited onto your
   avatar.

## How the "body scan" actually works

There's no photogrammetry or depth sensor here — it uses MediaPipe's Pose
Landmarker on a single webcam frame to get body keypoints (shoulders, hips,
knees, ankles, etc.), then derives proportions (shoulder width, waist width,
leg/arm length) from the distances between them. Because a single RGB camera
frame isn't reliably scaled to real-world units, the estimate is calibrated
using your self-reported height — the same approach real single-camera
measurement apps use. Treat it as a starting point; refine with the sliders.

## How the avatar and clothing work

The avatar is a procedural humanoid built from primitive geometry (capsules,
a sphere, boxes) whose proportions scale with your measurements — not a
rigged mesh or scan-to-mesh reconstruction. Clothing items are colored
overlays on the relevant body segments (torso, legs, feet), not simulated
cloth. This is the "fake the hard 5%, build the easy 95% well" approach:
it gets the wardrobe/outfit-builder product loop working end-to-end without
committing to unsolved research problems (garment-from-photo reconstruction,
real-time cloth physics) before the rest of the product is validated.

## Scope and honest limitations

- **No backend.** Auth, wardrobe, and measurements are all `localStorage` —
  fine for a single-device demo, not for a real multi-device product. Swap in
  Firebase (Auth + Firestore + Storage) or similar when ready.
- **No real garment assets.** Clothing is represented as colored geometry
  overlays, not actual 3D garment models. A real version would use a small
  curated library of pre-rigged glTF garments with blend shapes.
- **No true cloth physics.** Fit is a fixed geometric overlay, not simulated
  drape.
- **Pose-based measurements are approximate**, not medical/tailoring grade.
- **Camera access requires HTTPS (or localhost) and browser permission** —
  this won't work embedded in contexts that block camera access.

## Project structure

```
src/
  components/   Avatar3D, AvatarScene (3D scene), Nav, error boundary
  pages/        SignUp, BodyScan, Wardrobe, TryOn
  state/        React contexts for auth, avatar measurements, wardrobe
  lib/          types, localStorage helpers, pose-landmark math, MediaPipe loader
```
